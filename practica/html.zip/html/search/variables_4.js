var searchData=
[
  ['treecode',['treecode',['../class_idioma.html#ab80d7ef5fec4c922bc65e97e6e3bf968',1,'Idioma']]]
];
