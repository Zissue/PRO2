var searchData=
[
  ['lin',['lin',['../class_treecode.html#aa9722f48e4748f77b5e19686b5ccac66',1,'Treecode']]],
  ['lpre',['lpre',['../class_treecode.html#aded6560df5ed608f58310b90c9e272d4',1,'Treecode']]]
];
