var searchData=
[
  ['freqchart',['freqchart',['../class_idioma.html#ae3eb34e52b843df89bda82c8c4ca9aff',1,'Idioma']]]
];
