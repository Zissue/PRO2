var searchData=
[
  ['next_5fsymbol',['next_symbol',['../class_idioma.html#a9ff0debf6cbd4ae7b1b5cc7ec9ded194',1,'Idioma']]]
];
