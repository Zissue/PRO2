var searchData=
[
  ['idioma',['Idioma',['../class_idioma.html#a6722a621ce03825772493e67e5a17215',1,'Idioma::Idioma()'],['../class_idioma.html#a9a152381190573d8a13e3593c98ba96a',1,'Idioma::Idioma(Tabla &amp;chart)']]],
  ['inorder',['inorder',['../class_treecode.html#ad2fbdce7881906fb2e8163a196ef3611',1,'Treecode']]]
];
