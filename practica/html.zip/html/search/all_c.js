var searchData=
[
  ['size',['size',['../class_tabla.html#a140bc11d61c7cd365baa04f06635bdef',1,'Tabla']]],
  ['sumar_5ftablas',['sumar_tablas',['../class_idioma.html#af68e7f1aeb3e5d73184c3d2e3dd08457',1,'Idioma']]],
  ['sumpairs',['sumPairs',['../class_treecode.html#a1fe25b1f86068c064cfff5d865b6f37f',1,'Treecode']]]
];
