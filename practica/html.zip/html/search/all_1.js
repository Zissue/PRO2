var searchData=
[
  ['belong_5fand_5fdecode',['belong_and_decode',['../class_idioma.html#a235a873e0386dd21c3c3fba714f26683',1,'Idioma']]],
  ['belong_5ftext',['belong_text',['../class_idioma.html#af86e76455689f3c0d641737d1932fe4f',1,'Idioma']]],
  ['buildtreecode',['buildTreecode',['../class_treecode.html#a868dea4a6efcdcd1ad25580a0b15abfb',1,'Treecode']]]
];
