var searchData=
[
  ['add_5fidioma',['add_idioma',['../class_cjt__idiomas.html#ab0736d93ebd0fc1e45886111a88a5b9d',1,'Cjt_idiomas']]],
  ['arbol',['arbol',['../class_treecode.html#a43b786cc097e7466331274ba7d74c297',1,'Treecode']]]
];
