var searchData=
[
  ['add_5fidioma',['add_idioma',['../class_cjt__idiomas.html#ab0736d93ebd0fc1e45886111a88a5b9d',1,'Cjt_idiomas']]]
];
