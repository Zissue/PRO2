var searchData=
[
  ['práctica_20pro2_3a_20_20codificación_20y_20decodificación_20de_20palabras_20en_20varios_20idiomas_2e_20documentación_2e',['Práctica PRO2:  Codificación y decodificación de palabras en varios idiomas. Documentación.',['../index.html',1,'']]]
];
