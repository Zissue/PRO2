#include "Estudiant.hh"
#include <vector>

void max_min (const vector<Estudiant> &vest, double& notamax, double& notamin)
/* Pre: vest.size()>0, vest contiene al menos un elemento con nota */
/* Post: notamax es la nota maxima de los elementos de vest, 
         notamin es la nota minima de los elementos de vest */
{
 
}

// se puede buscar la primera nota valida en bucle aparte (asi, no
// hace falta consultarla, solo hay que usar te_nota()
