#include "Cjt_estudiants.hh"

void max_min (const Cjt_estudiants &c, double& notamax, double& notamin)
/* Pre: c.mida()>0, c contiene al menos un elemento con nota */
/* Post: notamax es la nota maxima de los elementos de c, 
         notamin es la nota minima de los elementos de c */
{
 
}

// se puede buscar la primera nota valida en bucle aparte (asi, no
// hace falta consultarla, solo hay que usar te_nota()
