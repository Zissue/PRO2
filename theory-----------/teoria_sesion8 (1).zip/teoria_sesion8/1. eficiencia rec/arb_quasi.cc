//jutge X64411

bool quasi_coinc (Arbre&<int> a1, Arbre&<int> a2){
  // return (quasi_coinc2(a1,a2)<2);
  //
  // parint<bool, bool> b;
  // b = quasi_coinc2(a1,a2);
  // return b.first;
}


pair<bool, bool> quasi_coinc1 (Arbre&<int> a1, Arbre&<int> a2)
/* Pre: cierto */
/* Post: la primera parte del resultado indica si a1 y a2 son qc.;
         la segunda parte indica si a1 y a2 son iguales */
{

}
 
int quasi_coinc2 (Arbre&<int> a1, Arbre&<int> a2)
/* Pre: cierto */
/* Post: el resultado es el num de diferencias de forma entre a1 y a2
{

}


// probar la que actualiza un parametro dif por referencia
