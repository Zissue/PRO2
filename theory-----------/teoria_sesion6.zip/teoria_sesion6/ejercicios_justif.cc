double nota_max (const vector<Estudiant> &vest)
/* Pre: vest.size()>0, vest contiene al menos un elemento con nota */
/* Post: el resultado es la nota maxima de los elementos de vest */
{
  // sol. con 1 bucle
  double n_max = ?;
  int i = ?; 
  // Inv:
  // Cota:
  while (i<v.size()){

  }

  // sol con 2 bucles


  return n_max;
}


bool es_capicua(const list<int>& l)
/* Pre: cert */
/* Post: El resultat indica si l �s capicua o no */
{
  if (l.empty()) return true;
  else {
    bool b;
    // inicializacion del booleano y los iterators
    // Inv:
    // Cota: 
    while () {
   
    }
    return b;
  }
}

// hacer primero la version vector

bool es_capicua(const vector<int>& v)
/* Pre: cert */
/* Post: El resultat indica si v �s capicua o no */
{
  int i = 0;
  bool b = true;
  // Inv:
  // Cota: 
  while () {
   
  }
  return b;
}
