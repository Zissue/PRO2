void insert_ord(list<int>& l, int x)
/* Pre: l=L, l esta ordenada */
/* Post: l �s com L pero amb x afegit on toca */
{

}


bool es_capicua(const list<int>& l)
/* Pre: cert */
/* Post: El resultat indica si l �s capicua o no */
{

}
