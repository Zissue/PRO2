void divisors(int n, stack<int> &p)
/* Pre: n>0, p és buida */
/* Post: p conté els divisors d’n menors que ell, en ordre decreixent
   des del cim */
{

}
