#include <iostream>
#include "LlistaIOParInt.hh"
using namespace std;

int main () {
    
    list<ParInt> a;
    LlegirLlistaParInt(a);
    
    int n, sum = 0, count = 0;
    cin >> n;
    
    for (list<ParInt>::const_iterator it = a.begin(); it != a.end(); it++) {
        if ((*it).primer() == n) {
            count++;
            sum += (*it).segon();
        }
    }
    cout << n << " " << count << " " << sum << endl;
}
